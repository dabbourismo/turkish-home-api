﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TurkishHomeApi.Models.Enums
{
    public enum EnumExamType
    {
        Permenant,
        Temporary
    }
}